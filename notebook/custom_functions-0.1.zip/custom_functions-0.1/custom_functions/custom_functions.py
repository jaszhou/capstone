from sklearn.base import BaseEstimator, TransformerMixin

def calcular_total_elemento(cantidades_fertilizantes, elemento):
    
    total_elemento = 0
    
    for fertilizante, cantidad in cantidades_fertilizantes:
        
        try:
            
            total_elemento += contenido_fertilizantes[fertilizante][elemento]*cantidad
            
        except KeyError:
            
            continue
            
    return total_elemento

def calcular_total_elementos(cantidades_fertilizantes, elementos):
    
    cantidades_elementos = {}
    
    for elemento in elementos:
    
        total = calcular_total_elemento(cantidades_fertilizantes, elemento)
    
        cantidades_elementos[elemento] = total
        
    return cantidades_elementos

def calcular_mejor_opcion(opcion_1, opcion_2):
    
    return opcion_1

def caso_base(cantidades_elementos):
    
    recomendacion_fertilizantes = []
    
    n = cantidades_elementos['n']
    p = cantidades_elementos['p']
    k = cantidades_elementos['k']
    ca = cantidades_elementos['ca']
    mg = cantidades_elementos['mg']
    fe = cantidades_elementos['fe']
    mn = cantidades_elementos['mn']
    zn = cantidades_elementos['zn']
    b = cantidades_elementos['b']
    
    recomendacion_fertilizantes.append(('s_zn', zn/0.28))
    recomendacion_fertilizantes.append(('s_mn', mn/0.3))
    recomendacion_fertilizantes.append(('s_fe', fe/0.19))
    recomendacion_fertilizantes.append(('borax', b/0.1))
    recomendacion_fertilizantes.append(('s_mg', mg/0.16))
    recomendacion_fertilizantes.append(('s_ca', ca/0.29))
    recomendacion_fertilizantes.append(('kcl', k/0.6))
    
    dap = p/0.46
    urea = (n - 0.18*dap)/0.46
    recomendacion_fertilizantes.append(('dap', dap))
    
    recomendacion_fertilizantes.append(('urea', urea))

    return recomendacion_fertilizantes

def caso_exceso_azufre_1(cantidades_elementos):
    
    recomendacion_fertilizantes = []
    
    p = cantidades_elementos['p']
    k = cantidades_elementos['k']
    ca = cantidades_elementos['ca']
    mg = cantidades_elementos['mg']
    fe = cantidades_elementos['fe']
    mn = cantidades_elementos['mn']
    zn = cantidades_elementos['zn']
    b = cantidades_elementos['b']
    
    recomendacion_fertilizantes.append(('quelato_zn', zn/0.12))
    recomendacion_fertilizantes.append(('s_mn', mn/0.3))
    recomendacion_fertilizantes.append(('s_fe', fe/0.19))
    recomendacion_fertilizantes.append(('borax', b/0.1))
    recomendacion_fertilizantes.append(('s_mg', mg/0.16))
    recomendacion_fertilizantes.append(('s_ca', ca/0.29))
    recomendacion_fertilizantes.append(('kcl', k/0.6))
    
    dap = p/0.46
    recomendacion_fertilizantes.append(('dap', dap))
    
    total_s = calcular_total_elemento(recomendacion_fertilizantes, 's')
    s_faltante = cantidades_elementos['s'] - total_s
    
    if s_faltante < 0:
        s_amonio = 0
    else:    
        s_amonio = s_faltante/0.24
    recomendacion_fertilizantes.append(('s_amonio', s_amonio))
    
    total_n = calcular_total_elemento(recomendacion_fertilizantes, 'n')
    n_faltante = cantidades_elementos['n'] - total_n
    
    urea = n_faltante/0.46    
    
    recomendacion_fertilizantes.append(('urea', urea))
    
    return recomendacion_fertilizantes

def caso_exceso_azufre_2(cantidades_elementos):
    
    recomendacion_fertilizantes = []
    
    p = cantidades_elementos['p']
    k = cantidades_elementos['k']
    ca = cantidades_elementos['ca']
    mg = cantidades_elementos['mg']
    fe = cantidades_elementos['fe']
    mn = cantidades_elementos['mn']
    zn = cantidades_elementos['zn']
    b = cantidades_elementos['b']
    
    recomendacion_fertilizantes.append(('s_zn', zn/0.28))
    recomendacion_fertilizantes.append(('s_mn', mn/0.12))
    recomendacion_fertilizantes.append(('s_fe', fe/0.19))
    recomendacion_fertilizantes.append(('borax', b/0.1))
    recomendacion_fertilizantes.append(('s_mg', mg/0.16))
    recomendacion_fertilizantes.append(('n_ca', ca/0.26))
    recomendacion_fertilizantes.append(('kcl', k/0.6))
    
    dap = p/0.46
    recomendacion_fertilizantes.append(('dap', dap))
    
    total_s = calcular_total_elemento(recomendacion_fertilizantes, 's')
    s_faltante = cantidades_elementos['s'] - total_s
    
    if s_faltante < 0:
        s_amonio = 0
    else:    
        s_amonio = s_faltante/0.24
        
    recomendacion_fertilizantes.append(('s_amonio', s_amonio))
    
    total_n = calcular_total_elemento(recomendacion_fertilizantes, 'n')
    n_faltante = cantidades_elementos['n'] - total_n
    
    if n_faltante < 0:
        urea = 0
    else:    
        urea = n_faltante/0.46   
    
    recomendacion_fertilizantes.append(('urea', urea))
    
    return recomendacion_fertilizantes

def caso_deficit_azufre(cantidades_elementos):
    
    recomendacion_fertilizantes = []
    
    p = cantidades_elementos['p']
    k = cantidades_elementos['k']
    ca = cantidades_elementos['ca']
    mg = cantidades_elementos['mg']
    fe = cantidades_elementos['fe']
    mn = cantidades_elementos['mn']
    zn = cantidades_elementos['zn']
    b = cantidades_elementos['b']
    
    recomendacion_fertilizantes.append(('s_zn', zn/0.28))
    recomendacion_fertilizantes.append(('s_mn', mn/0.12))
    recomendacion_fertilizantes.append(('s_fe', fe/0.19))
    recomendacion_fertilizantes.append(('borax', b/0.1))
    recomendacion_fertilizantes.append(('s_mg', mg/0.16))
    recomendacion_fertilizantes.append(('s_ca', ca/0.26))
    recomendacion_fertilizantes.append(('kcl', k/0.6))
    
    dap = p/0.46
    recomendacion_fertilizantes.append(('dap', dap))
    
    total_s = calcular_total_elemento(recomendacion_fertilizantes, 's')
    s_faltante = cantidades_elementos['s'] - total_s
    
    if s_faltante < 0:
        s_amonio = 0
    else:    
        s_amonio = s_faltante/0.24
        
    recomendacion_fertilizantes.append(('s_amonio', s_amonio))
    
    total_n = calcular_total_elemento(recomendacion_fertilizantes, 'n')
    n_faltante = cantidades_elementos['n'] - total_n
    
    if n_faltante < 0:
        urea = 0
    else:    
        urea = n_faltante/0.46   
    
    recomendacion_fertilizantes.append(('urea', urea))
    
    return recomendacion_fertilizantes

def escoger_mejor_opcion(opcion1, opcion2):
    
    return opcion2

def recomendacion_fertilizantes(cantidades_entrada_elementos, elementos, rango_error_azufre, rango_error_nitrogeno):
    
    recomendacion_base = caso_base(cantidades_entrada_elementos)
    
    resultado_elementos = calcular_total_elementos(recomendacion_base, elementos)
    
    error_azufre = resultado_elementos['s'] - cantidades_entrada_elementos['s']
    
    if abs(error_azufre) <= rango_error_azufre:
        
        recomendacion_fertilizantes = recomendacion_base
        
        return recomendacion_fertilizantes
    
    elif error_azufre > rango_error_azufre:
        
        #Caso exceso de azufre
        recomendacion_exceso_1 = caso_exceso_azufre_1(cantidades_entrada_elementos)
        resultado_elementos_1 = calcular_total_elementos(recomendacion_exceso_1, elementos)
        
        error_azufre = resultado_elementos_1['s'] - cantidades_entrada_elementos['s']
        error_nitrogeno = resultado_elementos['n'] - cantidades_entrada_elementos['n']
        
        if (error_azufre > rango_error_azufre) or (error_nitrogeno > rango_error_nitrogeno):
            
            recomendacion_exceso_2 = caso_exceso_azufre_2(cantidades_entrada_elementos)
            
            recomendacion_fertilizantes = escoger_mejor_opcion(recomendacion_exceso_1, recomendacion_exceso_2)
            
        else:
            
            recomendacion_fertilizantes = recomendacion_exceso_1
            
    
    elif error_azufre < rango_error_azufre:
        
        #Caso falta de azufre
 
        recomendacion_deficit = caso_deficit_azufre(cantidades_entrada_elementos)
        resultado_elementos = calcular_total_elementos(recomendacion_deficit, elementos)
        
        error_nitrogeno = resultado_elementos['n'] - cantidades_entrada_elementos['n']
        
        if abs(error_nitrogeno) > rango_error_nitrogeno:
            
            recomendacion_fertilizantes = escoger_mejor_opcion(recomendacion_deficit, recomendacion_base)
            
        else:
            recomendacion_fertilizantes = recomendacion_deficit

    return recomendacion_fertilizantes


def calcular_recomendacion_fertilizantes(cantidades_elementos):

    global contenido_fertilizantes

    contenido_fertilizantes = {'urea': {'n': 0.46},
                           'dap': {'n': 0.18,
                                   'p': 0.46
                                  },
                           'kcl': {'k': 0.6},
                           's_ca': {'ca': 0.29,
                                    's': 0.21
                                   },
                           's_mg': {'mg': 0.16,
                                    's': 0.16
                                   },
                           's_zn': {'zn': 0.28,
                                    's': 0.07
                                   },
                           'borax': {'b': 0.1},
                           's_mn': {'mn': 0.3,
                                    's': 0.12
                                   },
                           's_fe': {'fe': 0.19,
                                    's': 0.11
                                   },
                           's_amonio': {'n': 0.21,
                                        's': 0.24
                                       },
                           'n_ca': {'n': 0.15,
                                    'ca': 0.26
                                   },
                           'quelato_zn': {'zn': 0.12},
                           'quelato_mn': {'mn': 0.12}
                          }

    elementos = ['n', 'p', 'k', 'ca', 'mg', 's', 'b', 'zn', 'mn', 'fe']
    rango_error_azufre = 10
    rango_error_nitrogeno = 10

    recomendacion = recomendacion_fertilizantes(cantidades_elementos, elementos, rango_error_azufre, rango_error_nitrogeno)

    return recomendacion

class CombinacionPreprocesamiento(BaseEstimator, TransformerMixin):
    
    def __init__(self, cantidades_elementos=None):
        self.cantidades_elementos = cantidades_elementos
        
    def fit(self, X, y= None):
        return self
    
    def transform(self, cantidades_elementos):

        dict_list = []

        for i in range(cantidades_elementos.shape[0]):

            cantidades_elementos_dict = {
                'n': cantidades_elementos[i, 0],
                'p': cantidades_elementos[i,1],
                'mg': cantidades_elementos[i,2],
                's': cantidades_elementos[i,3],
                'fe': cantidades_elementos[i,4],
                'mn': cantidades_elementos[i,5],
                'zn': cantidades_elementos[i,6],
                'b': cantidades_elementos[i,7],
                'ca': cantidades_elementos[i,8],
                'k': cantidades_elementos[i,9]                         
            }

            dict_list.append(cantidades_elementos_dict)        
        

        return dict_list

class CombinacionFertilizante(BaseEstimator, TransformerMixin):
    
    def __init__(self, cantidades_elementos=None):
        self.cantidades_elementos = cantidades_elementos
        
    def fit(self, X, y= None):
        return self
    
    def predict(self, cantidades_elementos):

        cantidades_elementos_list = []
        recomendaciones_list = []

        for cantidad in cantidades_elementos:

            recomendacion = calcular_recomendacion_fertilizantes(cantidad)
            recomendaciones_list.append(recomendacion)
            cantidades_elementos_list.append(cantidad)


        return recomendaciones_list, cantidades_elementos_list

from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd

class DummyEncoder(BaseEstimator, TransformerMixin):
    
    def __init__(self, attribute_names=None):
        self.attribute_names = attribute_names
        
    def fit(self, X, y= None):
        return self
    
    def transform(self, X):
        return pd.get_dummies(X, columns=self.attribute_names)
    
class NumericalSelector(BaseEstimator, TransformerMixin):
    
    def __init__(self, attribute_names=None):
        self.attribute_names = attribute_names
        
    def fit(self, X, y= None):
        return self
    
    def transform(self, X):
        return X.select_dtypes(include='number')
    
class CategoricalSelector(BaseEstimator, TransformerMixin):
    
    def __init__(self, attribute_names=None):
        self.attribute_names = attribute_names
        
    def fit(self, X, y= None):
        return self
    
    def transform(self, X):
        return X.select_dtypes(include='category')
    
class DataFrameSelector(BaseEstimator, TransformerMixin):
    
    def __init__(self, attribute_names):
        self.attribute_names = attribute_names
        
    def fit(self, X, y= None):
        return self
    
    def transform(self, X):
        return X[self.attribute_names]
		
class ModelRegTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, model):
        self.model = model
    def fit(self, *args, **kwargs):
        self.model.fit(*args, **kwargs)
        return self
    def transform(self, X, **transform_params):
        return self.model.predict(X)

